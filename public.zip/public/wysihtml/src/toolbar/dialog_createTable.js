(function(wysihtml5) {
  wysihtml5.toolbar.Dialog_createTable = wysihtml5.toolbar.Dialog.extend({
    show: function(elementToChange) {
      this.base(elementToChange);
    }
  });
})(wysihtml5);
