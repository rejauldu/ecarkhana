@include('layouts.backend.header')
@yield('content')
@include('layouts.backend.footer')