<!--=================================
inner-intro -->

    <section class="inner-intro bg-1 bg-overlay-black-70" style="background-image: url({{ url('/') }}/images/accessories.jpg)">
        <div class="container">
            <div class="row text-center intro-title">
                <div class="col-md-6 text-md-left d-inline-block">
                    <h1 class="text-white">Hyundai Santa Fe </h1>
                </div>
                <div class="col-md-6 text-md-right float-right">
                    <ul class="page-breadcrumb">
                        <li><a href="#"><i class="fa fa-home"></i> Home</a> <i class="fa fa-angle-double-right"></i>
                        </li>

                        <li><span>Bike details</span> </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!--=================================
inner-intro -->